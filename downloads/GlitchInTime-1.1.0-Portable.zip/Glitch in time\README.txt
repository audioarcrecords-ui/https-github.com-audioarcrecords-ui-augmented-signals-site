Glitch in time v1.1.0 — Manual install (no installer)
========================================================

This ZIP contains the plugin in its raw, portable form: no installer,
no writes to Program Files, no registry changes. Just two things:

1. Glitch in time.exe
   — Standalone app. Just double-click to run it, no install needed.

2. Glitch in time.vst3
   — VST3 plugin. To use it in your DAW (Cubase, Ableton, FL Studio, etc.),
     copy the whole "Glitch in time.vst3" folder into your system VST3 folder:

       C:\Program Files\Common Files\VST3\

   Then rescan plugins in your DAW.

That's it — Glitch in time should now show up in your DAW's plugin list.

Need help? augmentedsignals.com
