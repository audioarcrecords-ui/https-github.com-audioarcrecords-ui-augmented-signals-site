@echo off
:: Copies "Glitch in time.vst3" into the system VST3 folder so DAWs can find it.
:: Requires admin rights (Program Files is a protected folder).

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo This needs to run as Administrator.
    echo Right-click this file and choose "Run as administrator", then try again.
    pause
    exit /b 1
)

set "SRC=%~dp0Glitch in time.vst3"
set "DEST=C:\Program Files\Common Files\VST3\Glitch in time.vst3"

echo Copying VST3 to %DEST% ...
robocopy "%SRC%" "%DEST%" /E /IS /IT >nul

if %errorLevel% leq 7 (
    echo Done. Rescan plugins in your DAW to find "Glitch in time".
) else (
    echo Something went wrong copying the files.
)
pause
